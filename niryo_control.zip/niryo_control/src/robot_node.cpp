#include "niryo_control/control.hpp"
using namespace qp_controller::robot;
using namespace qp_controller::tasks;
using namespace qp_controller::trajectory;
using namespace qp_controller::math;

using namespace Eigen;
using namespace pinocchio;
using namespace std;

int main(int argc, char **argv)
{
    ros::init(argc, argv, "niryo_controller");
    ros::NodeHandle nh;
    ros::Rate r(100);

    //RobotWrapper
    const string ur_model_path = "/home/chan/niryo_ws/src/niryo_robot_description/";
        vector<string> package_dirs;
    package_dirs.push_back(franka_model_path);
    string urdfFileName = package_dirs[0] + "/urdf/one/niryo_grip.urdf";
    RobotWrapper robot(urdfFileName, package_dirs, false);

    const Model& model = robot.model();
    Data data(robot.model());


    r.sleep();
    nq_ = robot.nq();
    ROS_INFO_STREAM(robot.model());
    initialize();

    //Publisher
    pub_ = nh.advertise<std_msgs::Float64MultiArray>("/position_controller/command", 5);
    sub_ = nh.subscribe("/joint_states" ,5 ,&JointStateCallback);
    srv_ = nh.serviceClient<controller_manager_msgs::SwitchController>("/controller_manager/switch_controller");

    //Joint - Task - Trajectory
    TaskJointPosture task("task-posture", robot);
    VectorXd Kp = 400. * VectorXd::Ones(nq_);
    VectorXd Kd = 40. * VectorXd::Ones(nq_);
    task.Kp(Kp);
    task.Kd(Kd);
    
    TrajectoryEuclidianCubic *traj = new TrajectoryEuclidianCubic("traj_joint");
    TrajectorySample sample;

    const double dt = 0.01;


    while(ros::ok())
    {
        key_event();
        if(mode_ == 1)
        {
            if(ctrl_init_){
                switch_ctrl(true);
                q_goal_ << 0.1, 0.1, 0.1, 0.1, 0.1, 0.1;
                traj->setInitSample(q_);
                traj->setDuration(1.0);
                traj->setStartTime(ros::Time::now().toSec());
                traj->setGoalSample(q_goal_);
                ctrl_init_ = false;
            }
            cout<<"a"<<endl;
            robot.computeAllTerms(data, q_, v_);
            traj->setCurrentTime(ros::Time::now().toSec());
            cout<<"b"<<endl;

            sample = traj->computeNext();
            task.setReference(sample);
            auto &constraint = task.compute(ros::Time::now().toSec(), q_, v_, data);

            Jinv_ = constraint.matrix().completeOrthogonalDecomposition().pseudoInverse();
            ConstRefVector dv = Jinv_ * constraint.vector();
            v_d_ = dt * dv;
            q_d_ = pinocchio::integrate(robot.model(), q_, dt * v_d_);

            joint_publish(q_d_);

            r.sleep();
            ros::spinOnce();
        }
    }




}

void initialize()
{
    
    q_.setZero(nq_);
    v_.setZero(nq_);
    q_d_ = q_;
    v_d_ = v_;
    q_goal_ = q_;

    Jinv_.resize(nq_,nq_);

    ctrl_init_ = false;

}

void JointStateCallback(const sensor_msgs::JointState::ConstPtr &msg)
{
    for (int i=0; i<nq_; i++){
        q_(i) = msg->position[i];
        v_(i) = msg->velocity[i];
    }
}
void switch_ctrl(bool controllertype)
{
    controller_manager_msgs::SwitchController switch_msg;

    if(controllertype)
    {
        switch_msg.request.start_controllers.push_back("position_controller");
        switch_msg.request.stop_controllers.push_back("arm_controller");

    }
    else
    {
        switch_msg.request.start_controllers.push_back("arm_controller");
        switch_msg.request.stop_controllers.push_back("position_controller");

    }
    switch_msg.request.strictness = 1;
    switch_msg.request.start_asap = true;
    switch_msg.request.timeout = 2.;
    srv_.call(switch_msg);
}


void key_event()
{
    if (kbhit()){
        int key = getchar();
        switch(key){
            case 'h': //home - joint posture
                cout<<"home"<<endl;
                ctrl_init_ = true;
                mode_ = 1;
                break;

            case 'g': //goal - se3
                cout<<"goal"<<endl;
                ctrl_init_ = true;
                mode_ = 2;
                break;

            case 'm': //move it mode_
                cout<<"moveit"<<endl;
                ctrl_init_ = false;
                mode_ = 3;
                break;
        }

    }
    
}

void joint_publish(Eigen::VectorXd q_d)
{
    std_msgs::Float64MultiArray joint_ctrl;
    for(int i=0; i<nq_; i++){
        joint_ctrl.data.push_back(q_d(i));
    }

    pub_.publish(joint_ctrl);
}
