from __future__ import print_function


import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QAction, QMainWindow, QGridLayout, QLabel, QVBoxLayout
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QCoreApplication, Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import numpy as np
import pinocchio as pin

import actionlib
import rospy
import copy
from sensor_msgs.msg import JointState
import tf
from tf.transformations import quaternion_matrix
import math
import geometry_msgs.msg
from std_msgs.msg import Float64
from copy import deepcopy 
import eigenpy
import cmd, sys, os
import ur_control.msg
from ur_client import Control
from ur_robot import UR_RobotWrapper
from ur_robot import UR_PostureCtrl

class MyApp(QMainWindow):

    def __init__(self):
        #ROS Settings
        rospy.init_node("ur_control",anonymous=True)
        self.joint_posture_action_client = actionlib.SimpleActionClient('/ur_control/joint_posture_ctrl',ur_control.msg.JointPostureCtrlAction)
        self.joint_posture_action_client.wait_for_server()
        self.se3_ctrl_action_client = actionlib.SimpleActionClient('/ur_control/se3_ctrl',ur_control.msg.SE3CtrlAction)
        self.se3_ctrl_action_client.wait_for_server()

        #Robor Wrapper
        self.robot = UR_RobotWrapper()
        self.joint_ctrl = UR_PostureCtrl(self.robot)

        #Joint State
        self.q_0 = []
        self.q_1 = []
        self.q_2 = []
        self.q_3 = []
        self.q_4 = []
        self.q_5 = []
        self.time = []
    
        self.q_plan_0=[]
        self.q_plan_1=[]
        self.q_plan_2=[]
        self.q_plan_3=[]
        self.q_plan_4=[]
        self.q_plan_5=[]

        

        #GUI Settings
        super().__init__()
        self.initUI()
    
    def initUI(self):
        #for plot
        self.plot_container = plot()

        #Gui window setting
        self.setWindowTitle("plot")
        self.setWindowIcon(QIcon('plot.png'))
        self.setGeometry(300,300,1200,900)
        self.statusBar().showMessage('Ready')

        #trigger - home
        homeAction = QAction(QIcon("home.png"),"Home", self)
        homeAction.setShortcut("Ctrl + H")
        homeAction.setStatusTip("Go to Home")
        homeAction.triggered.connect(self.do_home)

        #trigger - goal
        goalAction = QAction(QIcon("goal.png"),"Goal", self)
        goalAction.setShortcut("Ctrl + G")
        goalAction.setStatusTip("Go to goal")
        goalAction.triggered.connect(self.do_se3)

        #Menu Bar
        menubar = self.menuBar()
        menubar.setNativeMenuBar(False)
        filemenu = menubar.addMenu('&File')
        filemenu.addAction(homeAction)
        filemenu.addAction(goalAction)

        #Widget
        quit_btn = QPushButton("Quit",self)
        quit_btn.clicked.connect(QCoreApplication.instance().quit)
        self.label = QLabel("Visualizer")
        main_layout = QGridLayout()
        main_layout.setRowMinimumHeight(0, 5)  # setting layout parameters
        main_layout.setRowMinimumHeight(2, 10)
        main_layout.setRowMinimumHeight(4, 5)
                
        main_layout.addWidget(self.label, 1, 1, Qt.AlignHCenter)
        main_layout.addWidget(self.plot_container, 2, 1)
        main_layout.addWidget(quit_btn, 3, 1)        

        centralWidget = QWidget()
        centralWidget.setLayout(main_layout)

        self.setCentralWidget(centralWidget)

        self.show()

    def do_home(self):
        #Initialize
        self.initialize()
        q_init = deepcopy(self.robot.q)
        v_init = deepcopy(self.robot.v)

        #Set Goal
        q_goal = ur_control.msg.JointPostureCtrlGoal()
        q_goal.goal.position = [0 ,-1.0, 1.0,  0.0, 0.0, 0]
        q_goal.duration.data = 3.0

        #Send Goal
        r = rospy.Rate(10)
        stime = rospy.Time.now()
        self.joint_posture_action_client.send_goal(q_goal)

        #For Plot
        while True:
            #Calculate cubic trajectory
            self.q_plan_0.append(self.joint_ctrl.cubic_trajectory(stime,q_init,v_init,q_goal.goal.position,q_goal.duration.data,rospy.Time.now())[0])
            self.q_plan_1.append(self.joint_ctrl.cubic_trajectory(stime,q_init,v_init,q_goal.goal.position,q_goal.duration.data,rospy.Time.now())[1])
            self.q_plan_2.append(self.joint_ctrl.cubic_trajectory(stime,q_init,v_init,q_goal.goal.position,q_goal.duration.data,rospy.Time.now())[2])
            self.q_plan_3.append(self.joint_ctrl.cubic_trajectory(stime,q_init,v_init,q_goal.goal.position,q_goal.duration.data,rospy.Time.now())[3])
            self.q_plan_4.append(self.joint_ctrl.cubic_trajectory(stime,q_init,v_init,q_goal.goal.position,q_goal.duration.data,rospy.Time.now())[4])
            self.q_plan_5.append(self.joint_ctrl.cubic_trajectory(stime,q_init,v_init,q_goal.goal.position,q_goal.duration.data,rospy.Time.now())[5])



            self.time.append(rospy.Time.now().to_sec()-stime.to_sec())
            self.q_0.append(self.robot.q[0])
            self.q_1.append(self.robot.q[1])
            self.q_2.append(self.robot.q[2])
            self.q_3.append(self.robot.q[3])
            self.q_4.append(self.robot.q[4])
            self.q_5.append(self.robot.q[5])

            if (self.joint_posture_action_client.get_result()):
                print ("action succeed")
                break

            r.sleep()

        self.plot_container.draw_graph(np.array(self.q_0),np.array(self.q_1),np.array(self.q_2),np.array(self.q_3),np.array(self.q_4),np.array(self.q_5),np.array(self.q_plan_0),np.array(self.q_plan_1),np.array(self.q_plan_2),np.array(self.q_plan_3),np.array(self.q_plan_4),np.array(self.q_plan_5),np.array(self.time))


    def do_se3(self):
        #initialize
        self.initialize()

        #Set Goal
        se3_goal = ur_control.msg.SE3CtrlGoal()
        se3_goal.se3_goal.position.x = 0.4
        se3_goal.se3_goal.position.y = 0.2
        se3_goal.se3_goal.position.z = 0.5
        se3_goal.se3_goal.orientation.x = 0.0
        se3_goal.se3_goal.orientation.y = 0.0
        se3_goal.se3_goal.orientation.z = 0.0
        se3_goal.se3_goal.orientation.w = 1.0
        se3_goal.duration.data = 3.0
        se3_goal.glob.data = True

        #Send Goal
        r = rospy.Rate(10)
        stime = rospy.Time.now().to_sec()
        self.se3_ctrl_action_client.send_goal(se3_goal)

        #For Plot
        while True:
            self.time.append(rospy.Time.now().to_sec()-stime)
            self.q_0.append(self.robot.q[0])
            self.q_1.append(self.robot.q[1])
            self.q_2.append(self.robot.q[2])
            self.q_3.append(self.robot.q[3])
            self.q_4.append(self.robot.q[4])
            self.q_5.append(self.robot.q[5])

            if (self.se3_ctrl_action_client.get_result()):
                print ("action succeed")
                break
            r.sleep()

        # self.plot_container.draw_graph(np.array(self.q_0),np.array(self.q_1),np.array(self.q_2),np.array(self.q_3),np.array(self.q_4),np.array(self.q_5),,np.array(self.time))
        # print(np.matrix(self.robot.cubic_q))


    def initialize(self):

        self.q_0 = []
        self.q_1 = []
        self.q_2 = []
        self.q_3 = []
        self.q_4 = []
        self.q_5 = []
        self.time = []



class plot(FigureCanvas):
    def __init__(self):
        self.plot_colorbar = None
        self.plot_figure = plt.figure(figsize=(10, 10),clear= True)
        FigureCanvas.__init__(self, self.plot_figure)  # creating FigureCanvas
        self.ax1 = self.plot_figure.add_subplot(231)
        self.ax2 = self.plot_figure.add_subplot(232)
        self.ax3 = self.plot_figure.add_subplot(233)
        self.ax4 = self.plot_figure.add_subplot(234)
        self.ax5 = self.plot_figure.add_subplot(235)
        self.ax6 = self.plot_figure.add_subplot(236)

        self.setWindowTitle("figure")  # sets Window title
        


    def draw_graph(self, q_0,q_1,q_2,q_3,q_4,q_5,plan_0,plan_1,plan_2,plan_3,plan_4,plan_5, time):

        #Clear the Graph
        self.ax1.clear()
        self.ax2.clear()
        self.ax3.clear()
        self.ax4.clear()
        self.ax5.clear()
        self.ax6.clear()

        #Plot
        self.ax1.plot(time,q_0,'r-',time,plan_0,'g--')
        self.ax1.set_xlim([0,4])
        self.ax1.set_ylim([-3.14,3.14])
        self.ax1.set_xlabel("time")
        self.ax1.set_ylabel("Joint Angle of Joint1")

        self.ax2.plot(time,q_1,'r-',time,plan_1,'g--')
        self.ax2.set_xlim([0,4])
        self.ax2.set_ylim([-3.14,3.14])
        self.ax2.set_xlabel("time")
        self.ax2.set_ylabel("Joint Angle of Joint2")

        self.ax3.plot(time,q_2,'r-',time,plan_2,'g--')
        self.ax3.set_xlim([0,4])
        self.ax3.set_ylim([-3.14,3.14])
        self.ax3.set_xlabel("time")
        self.ax3.set_ylabel("Joint Angle of Joint3")

        self.ax4.plot(time,q_3,'r-',time,plan_3,'g--')
        self.ax4.set_xlim([0,4])
        self.ax4.set_ylim([-3.14,3.14])
        self.ax4.set_xlabel("time")
        self.ax4.set_ylabel("Joint Angle of Joint4")

        self.ax5.plot(time,q_4,'r-',time,plan_4,'g--')
        self.ax5.set_xlim([0,4])
        self.ax5.set_ylim([-3.14,3.14])
        self.ax5.set_xlabel("time")
        self.ax5.set_ylabel("Joint Angle of Joint5")

        self.ax6.plot(time,q_5,'r-',time,plan_5,'g--')
        self.ax6.set_xlim([0,4])
        self.ax6.set_ylim([-3.14,3.14])
        self.ax6.set_xlabel("time")
        self.ax6.set_ylabel("Joint Angle of Joint6")

        self.draw()     #Draw Graph  


if __name__ == "__main__":
    app = QApplication(sys.argv)
    ex = MyApp()
    sys.exit(app.exec())
