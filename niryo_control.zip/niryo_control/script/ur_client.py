from __future__ import print_function

import numpy as np
import pinocchio as pin

import actionlib
import rospy
import copy
from sensor_msgs.msg import JointState
import tf
from tf.transformations import quaternion_matrix
import math
import geometry_msgs.msg
from std_msgs.msg import Float64
from copy import deepcopy 
import eigenpy
import cmd, sys, os
import ur_control.msg

class Control:
    def __init__(self):        
        self.joint_posture_action_client = actionlib.SimpleActionClient('/ur_control/joint_posture_ctrl',ur_control.msg.JointPostureCtrlAction)
        self.joint_posture_action_client.wait_for_server()
        self.se3_ctrl_action_client = actionlib.SimpleActionClient('/ur_control/se3_ctrl',ur_control.msg.SE3CtrlAction)
        self.se3_ctrl_action_client.wait_for_server()

        # Get_target_and_eef(goal)
    
    def do_home(self):
        q_goal = ur_control.msg.JointPostureCtrlGoal()
        q_goal.goal.position = [0 ,-1.0, 1.0,  0.8, 0.3, 0]
        q_goal.duration.data = 3.0
        
        self.joint_posture_action_client.send_goal(q_goal)
        self.joint_posture_action_client.wait_for_result()

        if (self.joint_posture_action_client.get_result()):
            print ("action succeed")
        else:
            print ("action failed")

    def do_reach(self):
        q_goal = ur_control.msg.JointPostureCtrlGoal()
        q_goal.goal.position = [0,-1.0, -1.0,0,0,0]
        q_goal.duration.data = 3.0
        
        self.joint_posture_action_client.send_goal(q_goal)
        self.joint_posture_action_client.wait_for_result()

        if (self.joint_posture_action_client.get_result()):
            print ("action succeed")
        else:
            print ("action failed")

    def do_se3(self):
        se3_goal = ur_control.msg.SE3CtrlGoal()
        se3_goal.se3_goal.position.x = 0.3
        se3_goal.se3_goal.position.y = 0.4
        se3_goal.se3_goal.position.z = 0.6
        se3_goal.se3_goal.orientation.x = 0.0
        se3_goal.se3_goal.orientation.y = 0.0
        se3_goal.se3_goal.orientation.z = 0.0
        se3_goal.se3_goal.orientation.w = 1.0
        se3_goal.duration.data = 5.0
        se3_goal.glob.data = True
        
        self.se3_ctrl_action_client.send_goal(se3_goal)
        self.se3_ctrl_action_client.wait_for_result()

        if (self.se3_ctrl_action_client.get_result()):
            print ("action succeed")
        else:
            print ("action failed")

    def do_se3_2(self):
        se3_goal = ur_control.msg.SE3CtrlGoal()
        se3_goal.se3_goal.position.x = 0.1
        se3_goal.se3_goal.position.y = 0.0
        se3_goal.se3_goal.position.z = 0.0
        se3_goal.se3_goal.orientation.x = 0.0
        se3_goal.se3_goal.orientation.y = 0.0
        se3_goal.se3_goal.orientation.z = 0.1135466
        se3_goal.se3_goal.orientation.w = 0.9935327
        se3_goal.duration.data = 5.0
        se3_goal.glob.data = False
        
        self.se3_ctrl_action_client.send_goal(se3_goal)
        self.se3_ctrl_action_client.wait_for_result()

        if (self.se3_ctrl_action_client.get_result()):
            print ("action succeed")
        else:
            print ("action failed")
