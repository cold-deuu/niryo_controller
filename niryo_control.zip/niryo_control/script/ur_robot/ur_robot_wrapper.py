import numpy as np
import pinocchio as pin

import rospy
from sensor_msgs.msg import JointState
import tf
from tf.transformations import quaternion_matrix
import math
import actionlib
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from std_msgs.msg import Float64
from geometry_msgs.msg import Transform
from copy import deepcopy 

import eigenpy
eigenpy.switchToNumpyArray()

class UR_RobotWrapper:
    def __init__(self):
        folder = '/home/chan/total_ws/src/universal_robot/'
        urdfname = 'ur_description/urdf/ur5.urdf'
        self.robot = pin.RobotWrapper.BuildFromURDF(folder+urdfname, folder)
        self.model = self.robot.model
        self.q = self.robot.q0
        self.v = self.robot.v0
        self.cubic_q = []

        print ("ur 5 robot's urdf is loaded")

        rospy.Subscriber('joint_states', JointState, self.JointStateCB)
        
        self.joint_state = [0,0,0,0,0,0]
        
        self.joint_ctrl_pub = []
        self.joint_ctrl_pub.append(rospy.Publisher('/shoulder_pan_joint_controller/command', Float64, queue_size=10))
        self.joint_ctrl_pub.append(rospy.Publisher('/shoulder_lift_joint_controller/command', Float64, queue_size=10))
        self.joint_ctrl_pub.append(rospy.Publisher('/elbow_joint_controller/command', Float64, queue_size=10))
        self.joint_ctrl_pub.append(rospy.Publisher('/wrist_1_joint_controller/command', Float64, queue_size=10))
        self.joint_ctrl_pub.append(rospy.Publisher('/wrist_2_joint_controller/command', Float64, queue_size=10))
        self.joint_ctrl_pub.append(rospy.Publisher('/wrist_3_joint_controller/command', Float64, queue_size=10))
        
        self.joint_ctrl = []
        self.joint_ctrl.append(Float64())
        self.joint_ctrl.append(Float64())
        self.joint_ctrl.append(Float64())
        self.joint_ctrl.append(Float64())
        self.joint_ctrl.append(Float64())
        self.joint_ctrl.append(Float64())
        
        self.q_d = deepcopy(self.q)
        self.ee_id = self.model.getJointId("wrist_3_joint")
            
    def JointStateCB(self, msg):
        self.joint_state = msg

        for i in range(0, len(self.joint_state.name)):
            if self.joint_state.name[i] == "shoulder_pan_joint":
                self.q[0] = self.joint_state.position[2]
                self.v[0] = self.joint_state.velocity[2]
            if self.joint_state.name[i] == "shoulder_lift_joint":
                self.q[1] = self.joint_state.position[1]
                self.v[1] = self.joint_state.velocity[1]
            if self.joint_state.name[i] == "elbow_joint":
                self.q[2] = self.joint_state.position[0]
                self.v[2] = self.joint_state.velocity[0]
            if self.joint_state.name[i] == "wrist_1_joint":
                self.q[3] = self.joint_state.position[3]
                self.v[3] = self.joint_state.velocity[3]
            if self.joint_state.name[i] == "wrist_2_joint":
                self.q[4] = self.joint_state.position[4]
                self.v[4] = self.joint_state.velocity[4]
            if self.joint_state.name[i] == "wrist_3_joint":
                self.q[5] = self.joint_state.position[5]
                self.v[5] = self.joint_state.velocity[5]
     
        pin.computeAllTerms(self.model, self.robot.data, self.q, self.v)

    def GetEEPlacement(self):
        oMi = self.robot.data.oMi[self.ee_id]
        oMi_quat = pin.SE3ToXYZQUAT(oMi) # x, y, z , qx, qy, qz, qw
        
        ee_se3 = Transform()
        
        ee_se3.translation.x = oMi_quat[0]
        ee_se3.translation.y = oMi_quat[1]
        ee_se3.translation.z = oMi_quat[2]
        
        ee_se3.rotation.x = oMi_quat[3]
        ee_se3.rotation.y = oMi_quat[4]
        ee_se3.rotation.z = oMi_quat[5]
        ee_se3.rotation.w = oMi_quat[6]

        return ee_se3
