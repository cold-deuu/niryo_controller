import numpy as np
import pinocchio as pin

import rospy
from sensor_msgs.msg import JointState
import tf
from tf.transformations import quaternion_matrix
import math
import actionlib

from std_msgs.msg import Float64
from geometry_msgs.msg import Transform
from copy import deepcopy 

import eigenpy
eigenpy.switchToNumpyArray()

class UR_PostureCtrl:
    def __init__(self, robot):
        self.robot = robot # ur robot wrapper
        self.q_init = deepcopy(self.robot.q)
        self.v_init = deepcopy(self.robot.v)
        self.q_goal = deepcopy(self.robot.q)
        self.duration = 0.0
        self.stime = rospy.Time.now()

    def cubic_trajectory(self, ros_stime, q_init, q_dot_init, q_goal, duration, ros_time):
        stime = (ros_stime.to_sec() + ros_stime.to_nsec()) * pow(10, -9)
        time = (ros_time.to_sec() + ros_time.to_nsec()) * pow(10, -9)
        q_cubic = deepcopy(q_init)

        if (time < stime):
            return q_init
        elif (time > stime + duration):
            return q_goal
        else:
            for i in range(0, len(q_cubic)):
                a0 = q_init[i]
                a1 = 0.0
                a2 = 3.0 / pow(duration, 2) * (q_goal[i] - q_init[i])
                a3 = -1.0 * 2.0 / pow(duration, 3) * (q_goal[i] - q_init[i])
                q_cubic[i] = a0 + a1 * (time - stime) + a2 * pow(time-stime, 2) + a3 * pow(time-stime, 3)

            return q_cubic
        
    def setGoal(self, goal, duration, time):
        self.q_init = deepcopy(self.robot.q)
        self.v_init = deepcopy(self.robot.v)
        self.q_goal = goal
        self.duration = duration
        self.stime = time

    def compute(self, time):
        q_cubic = self.cubic_trajectory(self.stime, self.q_init, self.v_init, self.q_goal, self.duration, time)
        print(q_cubic)
        self.robot.q_d = q_cubic
        

class SE3_Control:
    def __init__(self, robot):
        self.robot = robot # ur robot wrapper
        self.q_init = deepcopy(self.robot.q)
        self.v_init = deepcopy(self.robot.v)
        self.q_goal = deepcopy(self.robot.q)
        self.duration = 0.0
        self.stime = rospy.Time.now()

    def q_cubic(self, ros_stime, q_init, q_dot_init, q_goal, duration, ros_time):
        stime = (ros_stime.to_sec() + ros_stime.to_nsec()) * pow(10, -9)
        time = (ros_time.to_sec() + ros_time.to_nsec()) * pow(10, -9)
        q_cubic = deepcopy(q_init)

        if (time < stime):
            return q_init
        elif (time > stime + duration):
            return q_goal
        else:
            for i in range(0, len(q_cubic)):
                a0 = q_init[i]
                a1 = q_dot_init[i]
                a2 = 3.0 / pow(duration, 2) * (q_goal[i] - q_init[i])
                a3 = -1.0 * 2.0 / pow(duration, 3) * (q_goal[i] - q_init[i])
                q_cubic[i] = a0 + a1 * (time - stime) + a2 * pow(time-stime, 2) + a3 * pow(time-stime, 3)
            return q_cubic

    def se3_cubic(self, ros_stime, se3_init, se3_goal, duration, ros_time):
        stime = (ros_stime.to_sec() + ros_stime.to_nsec()) * pow(10, -9)
        time = (ros_time.to_sec() + ros_time.to_nsec()) * pow(10, -9)
        se3_cubic = deepcopy(se3_goal)

        if (time < stime):
            return se3_init
        elif (time > stime + duration):
            return se3_goal
        else:
            rot_diff = pin.log3(np.asmatrix(se3_init.rotation).transpose() * np.asmatrix(se3_goal.rotation))
            tau = self.q_cubic(ros_stime, np.array([0.]), np.array([0.]), np.array([1.]), duration, ros_time)

            for i in range(0, 3):
                a0 = se3_init.translation[i]
                a1 = 0.0
                a2 = 3.0 / pow(duration, 2) * (se3_goal.translation[i] - se3_init.translation[i])
                a3 = -1.0 * 2.0 / pow(duration, 3) * (se3_goal.translation[i] - se3_init.translation[i])
                se3_cubic.translation[i] = a0 + a1 * (time - stime) + a2 * pow(time-stime, 2) + a3 * pow(time-stime, 3)
            se3_cubic.rotation = se3_init.rotation * np.matrix(pin.exp(rot_diff * tau))# * pin.exp(rot_diff * tau)
            return se3_cubic

    def quaternion_rotation_matrix(self, Q):
        q0 = Q[3]
        q1 = Q[0]
        q2 = Q[1]
        q3 = Q[2]
        
        # First row of the rotation matrix
        r00 = 2 * (q0 * q0 + q1 * q1) - 1
        r01 = 2 * (q1 * q2 - q0 * q3)
        r02 = 2 * (q1 * q3 + q0 * q2)
        
        # Second row of the rotation matrix
        r10 = 2 * (q1 * q2 + q0 * q3)
        r11 = 2 * (q0 * q0 + q2 * q2) - 1
        r12 = 2 * (q2 * q3 - q0 * q1)
        
        # Third row of the rotation matrix
        r20 = 2 * (q1 * q3 - q0 * q2)
        r21 = 2 * (q2 * q3 + q0 * q1)
        r22 = 2 * (q0 * q0 + q3 * q3) - 1
        
        # 3x3 rotation matrix
        rot_matrix = np.array([[r00, r01, r02],
                            [r10, r11, r12],
                            [r20, r21, r22]])
                                
        return rot_matrix
    
    def SetGoal(self, goal, duration, relative):
        self.ee_id = self.robot.ee_id
        self.oMi = self.robot.robot.data.oMi[self.ee_id]
        self.aduration = duration
        
        self.x_init = deepcopy(self.oMi)
        self.EE_goal = pin.SE3()
        self.EE_goal.translation = np.array(goal[:3])
        self.EE_goal.rotation = self.quaternion_rotation_matrix(goal[3:7])

        if (relative):            
            self.x_target = deepcopy(self.oMi) * self.EE_goal
        else:
            self.x_target = self.EE_goal
        
        self.stime = deepcopy(rospy.Time.now())
        self.p_gain = 1000.0
        self.dt = 0.001

    def se3_compute(self,time):
        x_cubic = self.se3_cubic(self.stime, self.x_init, self.x_target, self.aduration, time)
        x_current = self.robot.robot.data.oMi[self.ee_id]
        dMi = x_cubic.actInv(x_current) # self.target.inverse() * oMi

        q_d = self.robot.q

        err = np.zeros(6)
        err[:3] = dMi.translation # translation error
        err[3:6] = pin.log3(dMi.rotation) # rotation error
        err = np.asmatrix(err)

        J = np.asmatrix(self.robot.robot.getJointJacobian(self.ee_id, pin.ReferenceFrame.LOCAL ))
        J_inv = J.T * np.linalg.inv(J * J.T + 0.001 * np.matrix(np.eye((6))) )
        q_d_dot = J_inv * (-self.p_gain * err.T)
        q_d = pin.integrate(self.robot.model, self.robot.q, q_d_dot * self.dt) # new_q = q + self.v *dt
        self.robot.q_d = q_d
        
