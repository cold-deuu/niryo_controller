import numpy as np
import pinocchio as pin

import rospy
from sensor_msgs.msg import JointState
import tf
from tf.transformations import quaternion_matrix
import math
import actionlib

from std_msgs.msg import Float64, String
from geometry_msgs.msg import Transform
from copy import deepcopy 
import eigenpy
eigenpy.switchToNumpyArray()

from ur_robot import UR_RobotWrapper
from ur_server import Joint_Posture_Ctrl_Server
from ur_server import SE3_Ctrl_Server


if __name__ == '__main__':
    rospy.init_node('ur_control')
    robot = UR_RobotWrapper()
    ee_se3_pub = rospy.Publisher('ee_se3', Transform, queue_size=10)
    stime = rospy.Time.now()
    rate = rospy.Rate(100)
        
    ## action server
    joint_posture_action_server = Joint_Posture_Ctrl_Server('ur_control/joint_posture_ctrl', robot)
    se3_ctrl_action_server = SE3_Ctrl_Server('ur_control/se3_ctrl',robot)
    
    while not rospy.is_shutdown():
        ee_se3_pub.publish(robot.GetEEPlacement())
        joint_posture_action_server.compute(rospy.Time.now())
        se3_ctrl_action_server.compute(rospy.Time.now())

        if joint_posture_action_server.isrunning():                
            for j in range(0, 6):
                robot.joint_ctrl[j].data = robot.q_d[j]
                robot.joint_ctrl_pub[j].publish(robot.joint_ctrl[j])

        if se3_ctrl_action_server.isrunning():                
            for j in range(0, 6):
                robot.joint_ctrl[j].data = robot.q_d[j]
                robot.joint_ctrl_pub[j].publish(robot.joint_ctrl[j])
 
        rate.sleep()


