import numpy as np
import pinocchio as pin

import rospy
from sensor_msgs.msg import JointState
import tf
from tf.transformations import quaternion_matrix
import math
import actionlib
from ur_robot import UR_RobotWrapper, SE3_Control
import ur_control.msg

from copy import deepcopy 
import eigenpy
eigenpy.switchToNumpyArray()

class SE3_Ctrl_Server(object):
    _feedback = ur_control.msg.SE3CtrlFeedback()
    _result = ur_control.msg.SE3CtrlResult()

    def __init__(self, name,robot):
        self.se3_ctrl = SE3_Control(robot)
        self.robot = robot
        self._action_name = name
        self._as_se3 = actionlib.SimpleActionServer(self._action_name,ur_control.msg.SE3CtrlAction, auto_start= False)
        self._as_se3.register_goal_callback(self.se3_posture_cb)
        self._as_se3.register_preempt_callback(self.preempt_cb)
        self._as_se3.start()
        self.controller_run = False



    def se3_posture_cb(self):
        goal = self._as_se3.accept_new_goal()
        self.goal = goal
        np_goal = []
        np_goal.append(goal.se3_goal.position.x)
        np_goal.append(goal.se3_goal.position.y)
        np_goal.append(goal.se3_goal.position.z)
        np_goal.append(goal.se3_goal.orientation.x)
        np_goal.append(goal.se3_goal.orientation.y)
        np_goal.append(goal.se3_goal.orientation.z)
        np_goal.append(goal.se3_goal.orientation.w)

        
        
        self._result.se3_res.data = False
        self.start_time = rospy.Time.now()

        if (self.goal.glob.data):
            self.rel = False
        else:
            self.rel = True

        self.se3_ctrl.SetGoal(goal = np.array(np_goal),duration=self.goal.duration.data,relative=self.rel)
        self.np_goal = np_goal

        self.controller_run = True

    def preempt_cb(self):
        self._as_se3.set_preempted()
        self.controller_run = False

    def isrunning(self):
        return self.controller_run
    
    def compute(self, time):
        if not self.isrunning():
            return False
        self.omi = self.robot.robot.data.oMi[self.robot.ee_id]
        self.omi_quat = pin.SE3ToXYZQUAT(self.omi)
        self.se3_ctrl.se3_compute(rospy.Time.now())              
        eps = 1e-1

        if (self.rel):

            if ( (np.linalg.norm(self.robot.q - self.robot.q_d) < eps )and (time.to_sec() - self.start_time.to_sec() > self.goal.duration.data + 1.0)):
                self._result.se3_res.data = True
                self._as_se3.set_succeeded(self._result)
                self. controller_run = False
                print ("success")
                print(self.omi)
                return True
        
            elif (time.to_sec() - self.start_time.to_sec() > self.goal.duration.data + 2.0):
                self._as_se3.set_aborted()
                self. controller_run = False
                print ("failed")
                return False
            

        else:

            if ( (np.linalg.norm(self.omi_quat[:3] - self.np_goal[:3]) < eps )and (time.to_sec() - self.start_time.to_sec() > self.goal.duration.data + 1.0)):
                self._result.se3_res.data = True
                self._as_se3.set_succeeded(self._result)
                self. controller_run = False
                print ("success")
                print(self.omi)
                return True
        
            elif (time.to_sec() - self.start_time.to_sec() > self.goal.duration.data + 2.0):
                self._as_se3.set_aborted()
                self. controller_run = False
                print ("failed")
                return False