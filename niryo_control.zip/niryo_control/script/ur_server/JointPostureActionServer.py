import numpy as np
import pinocchio as pin

import rospy
from sensor_msgs.msg import JointState
import tf
from tf.transformations import quaternion_matrix
import math
import actionlib
from ur_robot import UR_RobotWrapper, UR_PostureCtrl
import ur_control.msg

from copy import deepcopy 
import eigenpy
eigenpy.switchToNumpyArray()

class Joint_Posture_Ctrl_Server(object):
    _feedback = ur_control.msg.JointPostureCtrlFeedback()
    _result = ur_control.msg.JointPostureCtrlResult()
    
    def __init__(self, name, robot):
        self.posture_ctrl = UR_PostureCtrl(robot)
        self._action_name = name
        self._as_joint = actionlib.SimpleActionServer(self._action_name, ur_control.msg.JointPostureCtrlAction, auto_start=False)
        self._as_joint.register_goal_callback(self.goal_cb)
        self._as_joint.register_preempt_callback(self.preempt_cb)
        self._as_joint.start()
        self.controller_run = False

    def goal_cb(self):
        goal = self._as_joint.accept_new_goal()
        self.goal = goal
        self._result.q_res.data = False
        self.start_time = rospy.Time.now()

        np_goal = []
        for i in range(len(goal.goal.position)):
            np_goal.append(goal.goal.position[i])

        self.posture_ctrl.setGoal(goal=np.array(np_goal), duration=goal.duration.data, time = self.start_time) 
        self.np_goal = np_goal

        self.controller_run = True

    def preempt_cb(self):
        self._as_joint.set_preempted()
        self.controller_run = False

    def isrunning(self):
        return self.controller_run
    
    def compute(self, time):
        if not self.isrunning():
            return False
        
        self.posture_ctrl.compute(time)
        eps = 1e-2

        if ( (np.linalg.norm(self.posture_ctrl.robot.q - self.np_goal) < eps )and (time.to_sec() - self.start_time.to_sec() > self.goal.duration.data + 1.0)):
            self._result.q_res.data = True
            self._as_joint.set_succeeded(self._result)
            self. controller_run = False
            print ("success")
            return True
        
        elif (time.to_sec() - self.start_time.to_sec() > self.goal.duration.data + 2.0):
            self._as_joint.set_aborted()
            self. controller_run = False
            print ("failed")
            return False

