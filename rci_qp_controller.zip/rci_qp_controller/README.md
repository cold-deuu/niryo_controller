# KIMM HQP Controller

1. Dependency

```sudo apt install robotpkg-py38-pinocchio robotpkg-eiquadprog ```


2. How to install

```mkdir build && cd build ```

```cmake .. ```

```ccmake .. ```  (set cmake install path as "/opt/openrobots", set build type as "Release")

```sudo make install ```
