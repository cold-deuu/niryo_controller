#ifndef __solver_fwd_hpp__
#define __solver_fwd_hpp__


#endif