#ifndef __task_fwd_hpp__
#define __task_fwd_hpp__

namespace qp_controller
{
  namespace tasks
  {
    
  }
}

#endif 