#ifndef __robots_fwd_hpp__
#define __robots_fwd_hpp__

namespace qp_controller
{
  class RobotWrapper;
}


#endif 