#ifndef __trajectory_fwd_hpp__
#define __trajectory_fwd_hpp__

#endif